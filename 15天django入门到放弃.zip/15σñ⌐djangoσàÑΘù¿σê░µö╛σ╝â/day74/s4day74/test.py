__author__ = 'Administrator'

# gpsd=f8fc689ea1d3382c1fbc0176b056c932

import requests

requests.post(
    url='http://dig.chouti.com/link/vote?linksId=12808296',
    cookies={
        'gpsd': 'f8fc689ea1d3382c1fbc0176b056c932'
    }
)