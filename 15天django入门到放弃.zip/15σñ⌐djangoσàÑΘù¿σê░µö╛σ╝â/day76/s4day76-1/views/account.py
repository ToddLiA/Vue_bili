__author__ = 'Administrator'
def index():
    return [b'index',]

def login():

    return [b'login',]